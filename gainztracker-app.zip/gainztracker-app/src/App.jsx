import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Dumbbell, Plus, Trash2, Timer, TrendingUp, Calendar, Trophy, ChevronDown, ChevronUp, Play, Pause, RotateCcw, Check, Flame, X, Bell, BellRing, Scale, Utensils, Target, LineChart, Moon, Sun, Apple, Beef, Droplets, Zap, Info, Clock, Camera, Download, Pizza, Upload, Image, CheckCircle2, AlertCircle, Smartphone, RefreshCw } from 'lucide-react';

// Veke's 6-Day PPL Split from the PDF
const WORKOUT_PLAN = {
  push_a: {
    name: "Push A (Heavy)",
    emoji: "🔥",
    day: 1,
    duration: "60-70 min",
    exercises: [
      { name: "Bench Press / Flat DB Press", sets: 4, reps: "5-8", rest: "2-3 min", muscle: "Chest" },
      { name: "Incline Barbell/DB Press", sets: 3, reps: "6-8", rest: "2-3 min", muscle: "Upper Chest" },
      { name: "Seated Shoulder Press", sets: 3, reps: "6-8", rest: "2-3 min", muscle: "Shoulders" },
      { name: "Weighted Dips / Machine Press", sets: 3, reps: "8-10", rest: "1.5-2 min", muscle: "Chest/Triceps" },
      { name: "Lateral Raises (light)", sets: 3, reps: "12-15", rest: "1 min", muscle: "Side Delts" },
      { name: "Triceps Rope Pushdown", sets: 3, reps: "10-12", rest: "1-1.5 min", muscle: "Triceps" },
    ]
  },
  pull_a: {
    name: "Pull A (Heavy)",
    emoji: "💪",
    day: 2,
    duration: "60-70 min",
    exercises: [
      { name: "Deadlift / Romanian Deadlift", sets: 3, reps: "4-6", rest: "2-3 min", muscle: "Back/Hamstrings" },
      { name: "Weighted Pull-ups / Lat Pulldown", sets: 4, reps: "6-8", rest: "2-3 min", muscle: "Lats" },
      { name: "Barbell Row / T-Bar Row", sets: 3, reps: "6-8", rest: "2-3 min", muscle: "Back" },
      { name: "Chest-Supported Row", sets: 3, reps: "8-10", rest: "1.5-2 min", muscle: "Back" },
      { name: "Barbell Curls", sets: 3, reps: "8-10", rest: "1.5-2 min", muscle: "Biceps" },
      { name: "Hammer Curls / DB Curls", sets: 2, reps: "10-12", rest: "1 min", muscle: "Biceps" },
    ]
  },
  legs_a: {
    name: "Legs A (Heavy)",
    emoji: "🦵",
    day: 3,
    duration: "65-75 min",
    exercises: [
      { name: "Back Squat / Front Squat", sets: 4, reps: "5-8", rest: "2-3 min", muscle: "Quads/Glutes" },
      { name: "Leg Press", sets: 3, reps: "8-10", rest: "2-3 min", muscle: "Quads" },
      { name: "Walking Lunges (DB)", sets: 3, reps: "10-12 each", rest: "1.5 min", muscle: "Quads/Glutes" },
      { name: "Leg Curl (Lying/Seated)", sets: 3, reps: "8-10", rest: "1.5-2 min", muscle: "Hamstrings" },
      { name: "Standing Calf Raises", sets: 4, reps: "10-15", rest: "1-1.5 min", muscle: "Calves" },
    ]
  },
  push_b: {
    name: "Push B (Pump)",
    emoji: "🎯",
    day: 4,
    duration: "55-65 min",
    exercises: [
      { name: "Incline Dumbbell Press", sets: 3, reps: "8-10", rest: "1.5-2 min", muscle: "Upper Chest" },
      { name: "Machine Chest Press / Push-ups", sets: 3, reps: "10-12", rest: "1 min", muscle: "Chest" },
      { name: "Arnold Press / DB Shoulder Press", sets: 3, reps: "8-10", rest: "1.5-2 min", muscle: "Shoulders" },
      { name: "High-rep Lateral Raises", sets: 4, reps: "15-20", rest: "45-60s", muscle: "Side Delts" },
      { name: "Cable Flyes (high to low)", sets: 3, reps: "12-15", rest: "1 min", muscle: "Chest" },
      { name: "Overhead Triceps Extension", sets: 3, reps: "12-15", rest: "1 min", muscle: "Triceps" },
    ]
  },
  pull_b: {
    name: "Pull B (Pump + Rear Delts)",
    emoji: "🏋️",
    day: 5,
    duration: "55-65 min",
    exercises: [
      { name: "Wide-grip Lat Pulldown", sets: 3, reps: "10-12", rest: "1.5-2 min", muscle: "Lats" },
      { name: "Seated Cable Row (close grip)", sets: 3, reps: "10-12", rest: "1.5-2 min", muscle: "Back" },
      { name: "One-arm Dumbbell Row", sets: 3, reps: "10 each", rest: "1 min", muscle: "Back" },
      { name: "Face Pulls (rear delts)", sets: 4, reps: "15-20", rest: "45-60s", muscle: "Rear Delts" },
      { name: "EZ-bar Curls", sets: 3, reps: "10-12", rest: "1 min", muscle: "Biceps" },
      { name: "Concentration / Preacher Curls", sets: 3, reps: "12-15", rest: "1 min", muscle: "Biceps" },
    ]
  },
  legs_b: {
    name: "Legs B + Core + Conditioning",
    emoji: "⚡",
    day: 6,
    duration: "65-75 min",
    exercises: [
      { name: "Front Squat / Goblet Squat", sets: 3, reps: "8-10", rest: "2-3 min", muscle: "Quads" },
      { name: "Romanian Deadlift", sets: 3, reps: "8-10", rest: "2-3 min", muscle: "Hamstrings" },
      { name: "Bulgarian Split Squat (DB)", sets: 3, reps: "10 each", rest: "1.5 min", muscle: "Quads/Glutes" },
      { name: "Seated/Donkey Calf Raises", sets: 4, reps: "12-15", rest: "1 min", muscle: "Calves" },
      { name: "Plank (weighted)", sets: 3, reps: "45-60s", rest: "1 min", muscle: "Core" },
      { name: "Hanging Leg Raises / Cable Crunch", sets: 3, reps: "12-15", rest: "1 min", muscle: "Core" },
    ]
  },
  rest: {
    name: "Rest Day",
    emoji: "😴",
    day: 7,
    duration: "Recovery",
    exercises: []
  }
};

const WEEKLY_SCHEDULE = [
  { day: "Monday", workout: "push_a", time: "22:00" },
  { day: "Tuesday", workout: "pull_a", time: "22:00" },
  { day: "Wednesday", workout: "legs_a", time: "23:00" },
  { day: "Thursday", workout: "rest", time: null },
  { day: "Friday", workout: "push_b", time: "22:30" },
  { day: "Saturday", workout: "legs_b", time: "19:00" },
  { day: "Sunday", workout: "pull_b", time: "Optional" },
];

const MACRO_TARGETS = {
  training: { calories: 2350, protein: 145, carbs: 275, fat: 65 },
  rest: { calories: 1900, protein: 133, carbs: 113, fat: 37 }
};

// Cheat meal options from the PDF
const CHEAT_MEAL_OPTIONS = [
  { name: "Pizza Night", emoji: "🍕", calories: "750-900", description: "3-4 large slices + soft drink/beer" },
  { name: "Burger + Fries", emoji: "🍔", calories: "~1,060", description: "Double cheeseburger + medium fries + Coke" },
  { name: "Takeaway Curry", emoji: "🍛", calories: "~1,080", description: "Chicken tikka masala + 2 naan + mango lassi" },
  { name: "Chinese Takeaway", emoji: "🥡", calories: "~950", description: "Sweet & sour chicken + fried rice + spring rolls" },
  { name: "McDonald's Combo", emoji: "🍟", calories: "~1,090", description: "Big Mac + medium fries + medium Coke" },
  { name: "Pasta Carbonara", emoji: "🍝", calories: "~1,050", description: "200g pasta + creamy sauce + garlic bread" },
  { name: "Dessert Night", emoji: "🍰", calories: "~800", description: "Ice cream + chocolate cake + 1 beer" },
  { name: "Full English", emoji: "🍳", calories: "~1,020", description: "Full breakfast with extra bacon + cappuccino" },
];

const REST_PRESETS = [60, 90, 120, 180];

// Weekly check-in questions
const CHECKIN_QUESTIONS = [
  { id: 'weight_change', question: 'Weight change this week?', type: 'select', options: ['Lost 0.5-1kg ✅', 'Lost >1kg ⚠️', 'No change', 'Gained weight'] },
  { id: 'gym_performance', question: 'Gym performance?', type: 'select', options: ['Added reps/weight 💪', 'Maintained', 'Decreased ⚠️'] },
  { id: 'energy', question: 'Energy & hunger levels?', type: 'select', options: ['Good energy, manageable hunger', 'Low energy', 'Very hungry', 'Both issues'] },
  { id: 'protein_compliance', question: 'Hit protein target (6/7 days)?', type: 'select', options: ['Yes (80%+) ✅', 'Mostly (60-80%)', 'No (<60%) ⚠️'] },
  { id: 'sleep', question: 'Average sleep this week?', type: 'select', options: ['7-9 hours ✅', '6-7 hours', '<6 hours ⚠️'] },
  { id: 'notes', question: 'Any notes or observations?', type: 'text' },
];

export default function VekeFitnessTracker() {
  const [activeTab, setActiveTab] = useState('today');
  const [currentWorkout, setCurrentWorkout] = useState(null);
  const [exerciseLogs, setExerciseLogs] = useState({});
  const [expandedExercise, setExpandedExercise] = useState(null);
  
  // Persistent data
  const [workoutHistory, setWorkoutHistory] = useState([]);
  const [personalBests, setPersonalBests] = useState({});
  const [dailyLogs, setDailyLogs] = useState([]);
  const [bodyMetrics, setBodyMetrics] = useState([]);
  const [streak, setStreak] = useState(0);
  const [lastWorkoutDate, setLastWorkoutDate] = useState(null);
  const [cheatMeals, setCheatMeals] = useState([]);
  const [weeklyCheckins, setWeeklyCheckins] = useState([]);
  const [progressPhotos, setProgressPhotos] = useState([]);
  
  // Timer
  const [restTimer, setRestTimer] = useState(90);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerValue, setTimerValue] = useState(90);
  
  // Daily logging
  const [todayLog, setTodayLog] = useState({
    weight: '', calories: '', protein: '', carbs: '', fat: '', water: '', sleep: '', notes: ''
  });
  
  // Notifications
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [reminderTime, setReminderTime] = useState('21:00');
  
  // UI state
  const [isLoading, setIsLoading] = useState(true);
  const [showCheatMealModal, setShowCheatMealModal] = useState(false);
  const [showCheckinModal, setShowCheckinModal] = useState(false);
  const [checkinAnswers, setCheckinAnswers] = useState({});
  const [showPhotoUpload, setShowPhotoUpload] = useState(false);
  const [installPrompt, setInstallPrompt] = useState(null);
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  
  const fileInputRef = useRef(null);

  // Get today's info
  const today = new Date();
  const dayName = today.toLocaleDateString('en-GB', { weekday: 'long' });
  const todaySchedule = WEEKLY_SCHEDULE.find(s => s.day === dayName);
  const todayWorkout = todaySchedule ? WORKOUT_PLAN[todaySchedule.workout] : null;
  const isRestDay = todaySchedule?.workout === 'rest';
  const isSunday = dayName === 'Sunday';
  const isSaturday = dayName === 'Saturday';
  const macroTarget = isRestDay ? MACRO_TARGETS.rest : MACRO_TARGETS.training;

  // PWA Install prompt
  useEffect(() => {
    const handleBeforeInstall = (e) => {
      e.preventDefault();
      setInstallPrompt(e);
      setShowInstallBanner(true);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  // Load data
  useEffect(() => {
    const loadData = async () => {
      try {
        const keys = ['workout-history', 'personal-bests', 'daily-logs', 'body-metrics', 'streak-data', 'notifications', 'cheat-meals', 'weekly-checkins', 'progress-photos'];
        const results = {};
        
        for (const key of keys) {
          try {
            const result = await window.storage.get(`veke-${key}`);
            if (result) results[key] = JSON.parse(result.value);
          } catch (e) {}
        }
        
        if (results['workout-history']) setWorkoutHistory(results['workout-history']);
        if (results['personal-bests']) setPersonalBests(results['personal-bests']);
        if (results['daily-logs']) {
          setDailyLogs(results['daily-logs']);
          const todayStr = new Date().toDateString();
          const existingLog = results['daily-logs'].find(l => new Date(l.date).toDateString() === todayStr);
          if (existingLog) {
            setTodayLog({
              weight: existingLog.weight || '',
              calories: existingLog.calories || '',
              protein: existingLog.protein || '',
              carbs: existingLog.carbs || '',
              fat: existingLog.fat || '',
              water: existingLog.water || '',
              sleep: existingLog.sleep || '',
              notes: existingLog.notes || ''
            });
          }
        }
        if (results['body-metrics']) setBodyMetrics(results['body-metrics']);
        if (results['streak-data']) {
          setStreak(results['streak-data'].streak || 0);
          setLastWorkoutDate(results['streak-data'].lastDate || null);
        }
        if (results['notifications']) {
          setNotificationsEnabled(results['notifications'].enabled || false);
          setReminderTime(results['notifications'].time || '21:00');
        }
        if (results['cheat-meals']) setCheatMeals(results['cheat-meals']);
        if (results['weekly-checkins']) setWeeklyCheckins(results['weekly-checkins']);
        if (results['progress-photos']) setProgressPhotos(results['progress-photos']);
      } catch (e) {
        console.log('Loading fresh state');
      }
      setIsLoading(false);
    };
    loadData();
  }, []);

  const saveData = useCallback(async (key, value) => {
    try {
      await window.storage.set(`veke-${key}`, JSON.stringify(value));
    } catch (e) {
      console.error('Save failed:', e);
    }
  }, []);

  // Timer
  useEffect(() => {
    let interval;
    if (timerRunning && timerValue > 0) {
      interval = setInterval(() => setTimerValue(v => v - 1), 1000);
    } else if (timerValue === 0) {
      setTimerRunning(false);
      if ('vibrate' in navigator) navigator.vibrate([200, 100, 200]);
      if (notificationsEnabled && 'Notification' in window && Notification.permission === 'granted') {
        new Notification('Rest Over! 💪', { body: 'Time for your next set!', icon: '🏋️' });
      }
    }
    return () => clearInterval(interval);
  }, [timerRunning, timerValue, notificationsEnabled]);

  // Check for Sunday check-in reminder
  useEffect(() => {
    if (isSunday && notificationsEnabled) {
      const lastCheckin = weeklyCheckins[0];
      const lastCheckinDate = lastCheckin ? new Date(lastCheckin.date).toDateString() : null;
      if (lastCheckinDate !== today.toDateString()) {
        // Show check-in prompt
        setShowCheckinModal(true);
      }
    }
  }, [isSunday, notificationsEnabled, weeklyCheckins]);

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        setNotificationsEnabled(true);
        await saveData('notifications', { enabled: true, time: reminderTime });
        new Notification('GainzTracker 💪', {
          body: 'Notifications enabled! You\'ll get daily workout reminders.',
          icon: '🏋️'
        });
      }
    }
  };

  const handleInstallPWA = async () => {
    if (installPrompt) {
      installPrompt.prompt();
      const result = await installPrompt.userChoice;
      if (result.outcome === 'accepted') {
        setShowInstallBanner(false);
      }
      setInstallPrompt(null);
    }
  };

  const startWorkout = (workoutKey) => {
    const workout = WORKOUT_PLAN[workoutKey];
    setCurrentWorkout({ ...workout, key: workoutKey });
    setExerciseLogs({});
    setExpandedExercise(0);
    setActiveTab('workout');
  };

  const logSet = (exerciseIndex, setIndex, weight, reps) => {
    const key = `${exerciseIndex}-${setIndex}`;
    setExerciseLogs(prev => ({
      ...prev,
      [key]: { weight: parseFloat(weight) || 0, reps: parseInt(reps) || 0 }
    }));
  };

  const finishWorkout = async () => {
    if (!currentWorkout) return;
    
    const todayStr = new Date().toDateString();
    const workoutData = {
      date: new Date().toISOString(),
      type: currentWorkout.key,
      name: currentWorkout.name,
      exercises: currentWorkout.exercises.map((ex, i) => ({
        ...ex,
        logged: Object.entries(exerciseLogs)
          .filter(([k]) => k.startsWith(`${i}-`))
          .map(([, v]) => v)
      }))
    };

    const newPBs = { ...personalBests };
    workoutData.exercises.forEach(ex => {
      ex.logged.forEach(set => {
        if (set.weight > 0) {
          const currentPB = newPBs[ex.name] || 0;
          if (set.weight > currentPB) newPBs[ex.name] = set.weight;
        }
      });
    });

    let newStreak = streak;
    if (lastWorkoutDate !== todayStr) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      newStreak = lastWorkoutDate === yesterday.toDateString() ? streak + 1 : 1;
    }

    const newHistory = [workoutData, ...workoutHistory].slice(0, 100);
    
    setWorkoutHistory(newHistory);
    setPersonalBests(newPBs);
    setStreak(newStreak);
    setLastWorkoutDate(todayStr);
    
    await saveData('workout-history', newHistory);
    await saveData('personal-bests', newPBs);
    await saveData('streak-data', { streak: newStreak, lastDate: todayStr });
    
    setCurrentWorkout(null);
    setExerciseLogs({});
    setActiveTab('progress');
  };

  const saveDailyLog = async () => {
    const todayStr = new Date().toISOString();
    const logEntry = { date: todayStr, ...todayLog };
    
    const todayDate = new Date().toDateString();
    const existingIndex = dailyLogs.findIndex(l => new Date(l.date).toDateString() === todayDate);
    
    let newLogs;
    if (existingIndex >= 0) {
      newLogs = [...dailyLogs];
      newLogs[existingIndex] = logEntry;
    } else {
      newLogs = [logEntry, ...dailyLogs].slice(0, 365);
    }
    
    setDailyLogs(newLogs);
    await saveData('daily-logs', newLogs);
    
    if (todayLog.weight) {
      const newMetrics = [
        { date: todayStr, weight: parseFloat(todayLog.weight) },
        ...bodyMetrics.filter(m => new Date(m.date).toDateString() !== todayDate)
      ].slice(0, 365);
      setBodyMetrics(newMetrics);
      await saveData('body-metrics', newMetrics);
    }
  };

  const logCheatMeal = async (meal) => {
    const cheatEntry = {
      date: new Date().toISOString(),
      meal: meal.name,
      emoji: meal.emoji,
      calories: meal.calories,
      description: meal.description
    };
    const newCheatMeals = [cheatEntry, ...cheatMeals].slice(0, 52);
    setCheatMeals(newCheatMeals);
    await saveData('cheat-meals', newCheatMeals);
    setShowCheatMealModal(false);
  };

  const saveWeeklyCheckin = async () => {
    const checkinEntry = {
      date: new Date().toISOString(),
      week: Math.ceil((today - new Date(today.getFullYear(), 0, 1)) / (7 * 24 * 60 * 60 * 1000)),
      answers: checkinAnswers
    };
    const newCheckins = [checkinEntry, ...weeklyCheckins].slice(0, 52);
    setWeeklyCheckins(newCheckins);
    await saveData('weekly-checkins', newCheckins);
    setShowCheckinModal(false);
    setCheckinAnswers({});
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = async (event) => {
      const photoEntry = {
        date: new Date().toISOString(),
        data: event.target.result,
        weight: bodyMetrics[0]?.weight || null
      };
      const newPhotos = [photoEntry, ...progressPhotos].slice(0, 24);
      setProgressPhotos(newPhotos);
      await saveData('progress-photos', newPhotos);
      setShowPhotoUpload(false);
    };
    reader.readAsDataURL(file);
  };

  const exportToCSV = () => {
    // Prepare workout data
    let csv = 'WORKOUT HISTORY\n';
    csv += 'Date,Workout,Exercises Logged\n';
    workoutHistory.forEach(w => {
      csv += `${new Date(w.date).toLocaleDateString('en-GB')},${w.name},${w.exercises.filter(e => e.logged?.length > 0).length}/${w.exercises.length}\n`;
    });
    
    csv += '\nDAILY LOGS\n';
    csv += 'Date,Weight (kg),Calories,Protein (g),Carbs (g),Fat (g),Water (L),Sleep (hrs),Notes\n';
    dailyLogs.forEach(l => {
      csv += `${new Date(l.date).toLocaleDateString('en-GB')},${l.weight || ''},${l.calories || ''},${l.protein || ''},${l.carbs || ''},${l.fat || ''},${l.water || ''},${l.sleep || ''},"${l.notes || ''}"\n`;
    });
    
    csv += '\nPERSONAL BESTS\n';
    csv += 'Exercise,Weight (kg)\n';
    Object.entries(personalBests).forEach(([ex, weight]) => {
      csv += `"${ex}",${weight}\n`;
    });
    
    csv += '\nWEEKLY CHECK-INS\n';
    csv += 'Date,Weight Change,Gym Performance,Energy,Protein Compliance,Sleep,Notes\n';
    weeklyCheckins.forEach(c => {
      const a = c.answers;
      csv += `${new Date(c.date).toLocaleDateString('en-GB')},${a.weight_change || ''},${a.gym_performance || ''},${a.energy || ''},${a.protein_compliance || ''},${a.sleep || ''},"${a.notes || ''}"\n`;
    });
    
    csv += '\nCHEAT MEALS\n';
    csv += 'Date,Meal,Calories\n';
    cheatMeals.forEach(c => {
      csv += `${new Date(c.date).toLocaleDateString('en-GB')},${c.meal},${c.calories}\n`;
    });

    // Download
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `veke-fitness-data-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getWeeklyStats = () => {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    const weekWorkouts = workoutHistory.filter(w => new Date(w.date) >= weekAgo);
    const weekLogs = dailyLogs.filter(l => new Date(l.date) >= weekAgo);
    
    const avgCalories = weekLogs.length > 0 
      ? Math.round(weekLogs.reduce((sum, l) => sum + (parseFloat(l.calories) || 0), 0) / weekLogs.length)
      : 0;
    const avgProtein = weekLogs.length > 0
      ? Math.round(weekLogs.reduce((sum, l) => sum + (parseFloat(l.protein) || 0), 0) / weekLogs.length)
      : 0;
      
    return { workouts: weekWorkouts.length, avgCalories, avgProtein };
  };

  const getMonthlyProgress = () => {
    const monthAgo = new Date();
    monthAgo.setDate(monthAgo.getDate() - 30);
    
    const monthMetrics = bodyMetrics.filter(m => new Date(m.date) >= monthAgo).sort((a, b) => new Date(a.date) - new Date(b.date));
    
    if (monthMetrics.length < 2) return null;
    
    const startWeight = monthMetrics[0].weight;
    const endWeight = monthMetrics[monthMetrics.length - 1].weight;
    const change = (endWeight - startWeight).toFixed(1);
    
    return { startWeight, endWeight, change, data: monthMetrics };
  };

  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const clearAllData = async () => {
    if (confirm('Delete all data? This cannot be undone.')) {
      const keys = ['workout-history', 'personal-bests', 'daily-logs', 'body-metrics', 'streak-data', 'cheat-meals', 'weekly-checkins', 'progress-photos'];
      for (const key of keys) {
        try { await window.storage.delete(`veke-${key}`); } catch (e) {}
      }
      setWorkoutHistory([]);
      setPersonalBests({});
      setDailyLogs([]);
      setBodyMetrics([]);
      setStreak(0);
      setLastWorkoutDate(null);
      setCheatMeals([]);
      setWeeklyCheckins([]);
      setProgressPhotos([]);
      setTodayLog({ weight: '', calories: '', protein: '', carbs: '', fat: '', water: '', sleep: '', notes: '' });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white text-xl flex items-center gap-3">
          <Dumbbell className="animate-bounce" /> Loading your gains...
        </div>
      </div>
    );
  }

  const weeklyStats = getWeeklyStats();
  const monthlyProgress = getMonthlyProgress();

  return (
    <div className="min-h-screen bg-gray-900 text-white pb-20">
      {/* PWA Install Banner */}
      {showInstallBanner && (
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            <span className="text-sm font-medium">Install app for offline access + notifications</span>
          </div>
          <div className="flex gap-2">
            <button onClick={handleInstallPWA} className="bg-white text-green-700 px-3 py-1 rounded-lg text-sm font-semibold">
              Install
            </button>
            <button onClick={() => setShowInstallBanner(false)} className="text-white/70 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 p-4 shadow-lg">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          <div className="flex items-center gap-2">
            <Dumbbell className="w-7 h-7" />
            <div>
              <h1 className="text-lg font-bold">Veke's GainzTracker</h1>
              <p className="text-xs text-white/70">6-Day PPL • 72kg → 68kg</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-white/20 px-3 py-1.5 rounded-full">
              <Flame className="w-4 h-4 text-orange-400" />
              <span className="font-bold">{streak}</span>
            </div>
            <button
              onClick={requestNotificationPermission}
              className={`p-2 rounded-full ${notificationsEnabled ? 'bg-green-500/30' : 'bg-white/20'}`}
            >
              {notificationsEnabled ? <BellRing className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
            </button>
            <button onClick={exportToCSV} className="p-2 rounded-full bg-white/20 hover:bg-white/30" title="Export Data">
              <Download className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex border-b border-gray-700 max-w-2xl mx-auto overflow-x-auto scrollbar-hide">
        {[
          { id: 'today', label: 'Today', icon: Sun },
          { id: 'workout', label: 'Workout', icon: Dumbbell },
          { id: 'log', label: 'Log', icon: Utensils },
          { id: 'progress', label: 'Progress', icon: LineChart },
          { id: 'photos', label: 'Photos', icon: Camera },
          { id: 'timer', label: 'Timer', icon: Timer },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-3 px-2 flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap min-w-fit ${
              activeTab === tab.id 
                ? 'bg-gray-800 text-purple-400 border-b-2 border-purple-400' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span className="text-xs sm:text-sm">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="max-w-2xl mx-auto p-4">
        {/* TODAY TAB */}
        {activeTab === 'today' && (
          <div className="space-y-4">
            {/* Sunday Check-in Reminder */}
            {isSunday && (
              <button
                onClick={() => setShowCheckinModal(true)}
                className="w-full bg-gradient-to-r from-yellow-600/30 to-orange-600/30 border border-yellow-500/50 rounded-xl p-4 flex items-center gap-3 hover:border-yellow-400 transition-colors"
              >
                <CheckCircle2 className="w-8 h-8 text-yellow-400" />
                <div className="text-left">
                  <h3 className="font-semibold text-yellow-400">Weekly Check-in Time!</h3>
                  <p className="text-sm text-gray-400">Tap to review your week and plan ahead</p>
                </div>
              </button>
            )}

            {/* Today's Workout Card */}
            <div className={`rounded-xl p-5 ${isRestDay ? 'bg-gradient-to-br from-blue-900/50 to-indigo-900/50' : 'bg-gradient-to-br from-purple-900/50 to-pink-900/50'}`}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-400">{dayName}</p>
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    {todayWorkout?.emoji} {todayWorkout?.name}
                  </h2>
                  {!isRestDay && todaySchedule && (
                    <p className="text-gray-400 text-sm mt-1">
                      <Clock className="w-4 h-4 inline mr-1" />
                      {todaySchedule.time} • {todayWorkout?.duration}
                    </p>
                  )}
                </div>
                {!isRestDay && (
                  <button
                    onClick={() => startWorkout(todaySchedule.workout)}
                    className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg font-semibold transition-colors"
                  >
                    Start
                  </button>
                )}
              </div>
              
              {isRestDay && (
                <div className="mt-4 p-3 bg-white/10 rounded-lg">
                  <p className="text-sm">🧘 Focus on recovery: stretch, light walk, meal prep</p>
                </div>
              )}
            </div>

            {/* Saturday Cheat Meal */}
            {isSaturday && (
              <button
                onClick={() => setShowCheatMealModal(true)}
                className="w-full bg-gradient-to-r from-pink-900/40 to-red-900/40 border border-pink-500/50 rounded-xl p-4 flex items-center gap-3 hover:border-pink-400 transition-colors"
              >
                <Pizza className="w-8 h-8 text-pink-400" />
                <div className="text-left">
                  <h3 className="font-semibold text-pink-400">Cheat Meal Day! 🎉</h3>
                  <p className="text-sm text-gray-400">Tap to log your weekly treat (post-workout)</p>
                </div>
              </button>
            )}

            {/* Weekly Schedule */}
            <div className="bg-gray-800 rounded-xl p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-purple-400" /> This Week
              </h3>
              <div className="space-y-2">
                {WEEKLY_SCHEDULE.map((schedule, i) => {
                  const workout = WORKOUT_PLAN[schedule.workout];
                  const isToday = schedule.day === dayName;
                  const dayWorkouts = workoutHistory.filter(w => {
                    const wDate = new Date(w.date);
                    const scheduleDay = WEEKLY_SCHEDULE.findIndex(s => s.day === schedule.day);
                    const todayIdx = WEEKLY_SCHEDULE.findIndex(s => s.day === dayName);
                    const diff = todayIdx - scheduleDay;
                    const targetDate = new Date();
                    targetDate.setDate(targetDate.getDate() - diff);
                    return wDate.toDateString() === targetDate.toDateString();
                  });
                  const completed = dayWorkouts.length > 0;
                  
                  return (
                    <div
                      key={i}
                      className={`flex items-center justify-between p-2 rounded-lg ${
                        isToday ? 'bg-purple-600/30 border border-purple-500' : 'bg-gray-700/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-8 text-center text-sm font-medium text-gray-400">
                          {schedule.day.slice(0, 3)}
                        </span>
                        <span className="text-lg">{workout.emoji}</span>
                        <span className={`text-sm ${schedule.workout === 'rest' ? 'text-gray-500' : ''}`}>
                          {workout.name.replace(' (Heavy)', '').replace(' (Pump)', '').replace(' + Core + Conditioning', '').replace(' + Rear Delts', '')}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {schedule.time && schedule.workout !== 'rest' && (
                          <span className="text-xs text-gray-500">{schedule.time}</span>
                        )}
                        {completed && <Check className="w-4 h-4 text-green-500" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-gray-800 rounded-xl p-3 text-center">
                <Dumbbell className="w-5 h-5 mx-auto mb-1 text-purple-400" />
                <p className="text-xl font-bold">{weeklyStats.workouts}/6</p>
                <p className="text-xs text-gray-400">This Week</p>
              </div>
              <div className="bg-gray-800 rounded-xl p-3 text-center">
                <Beef className="w-5 h-5 mx-auto mb-1 text-red-400" />
                <p className="text-xl font-bold">{weeklyStats.avgProtein}g</p>
                <p className="text-xs text-gray-400">Avg Protein</p>
              </div>
              <div className="bg-gray-800 rounded-xl p-3 text-center">
                <Scale className="w-5 h-5 mx-auto mb-1 text-blue-400" />
                <p className="text-xl font-bold">{bodyMetrics[0]?.weight || '--'}kg</p>
                <p className="text-xs text-gray-400">Current</p>
              </div>
            </div>

            {/* Target Reminder */}
            <div className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-700/50 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Target className="w-5 h-5 text-green-400 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-green-400">Goal: 68-69 kg</h4>
                  <p className="text-sm text-gray-400">Current: {bodyMetrics[0]?.weight || 72}kg • Timeline: 8-10 weeks</p>
                  {monthlyProgress && (
                    <p className="text-sm mt-1">
                      Monthly change: <span className={parseFloat(monthlyProgress.change) < 0 ? 'text-green-400' : 'text-orange-400'}>
                        {parseFloat(monthlyProgress.change) > 0 ? '+' : ''}{monthlyProgress.change}kg
                      </span>
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* WORKOUT TAB */}
        {activeTab === 'workout' && !currentWorkout && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-gray-300">Select Workout</h2>
            <div className="grid gap-3">
              {Object.entries(WORKOUT_PLAN).filter(([k]) => k !== 'rest').map(([key, workout]) => (
                <button
                  key={key}
                  onClick={() => startWorkout(key)}
                  className="bg-gray-800 hover:bg-gray-750 border border-gray-700 hover:border-purple-500 rounded-xl p-4 text-left transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl mr-2">{workout.emoji}</span>
                      <span className="text-lg font-semibold">{workout.name}</span>
                      <p className="text-gray-400 text-sm mt-1">
                        {workout.exercises.length} exercises • {workout.duration}
                      </p>
                    </div>
                    <ChevronDown className="w-5 h-5 text-gray-500" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Active Workout */}
        {activeTab === 'workout' && currentWorkout && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold">{currentWorkout.emoji} {currentWorkout.name}</h2>
                <p className="text-gray-400 text-sm">{currentWorkout.exercises.length} exercises • {currentWorkout.duration}</p>
              </div>
              <button onClick={() => setCurrentWorkout(null)} className="text-gray-400 hover:text-red-400 p-2">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              {currentWorkout.exercises.map((exercise, exIndex) => (
                <div key={exIndex} className="bg-gray-800 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setExpandedExercise(expandedExercise === exIndex ? null : exIndex)}
                    className="w-full p-4 flex items-center justify-between hover:bg-gray-750 transition-colors"
                  >
                    <div className="text-left">
                      <h3 className="font-semibold">{exercise.name}</h3>
                      <p className="text-sm text-gray-400">
                        {exercise.muscle} • {exercise.sets} × {exercise.reps} • Rest {exercise.rest}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {Object.keys(exerciseLogs).filter(k => k.startsWith(`${exIndex}-`)).length === exercise.sets && (
                        <Check className="w-5 h-5 text-green-500" />
                      )}
                      {expandedExercise === exIndex ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </button>
                  
                  {expandedExercise === exIndex && (
                    <div className="px-4 pb-4 space-y-2">
                      {personalBests[exercise.name] && (
                        <div className="flex items-center gap-1 text-xs text-yellow-500 mb-2">
                          <Trophy className="w-3 h-3" />
                          PB: {personalBests[exercise.name]}kg
                        </div>
                      )}
                      {Array.from({ length: exercise.sets }).map((_, setIndex) => {
                        const log = exerciseLogs[`${exIndex}-${setIndex}`] || {};
                        return (
                          <div key={setIndex} className="flex items-center gap-2 bg-gray-700/50 rounded-lg p-2">
                            <span className="text-sm text-gray-400 w-14">Set {setIndex + 1}</span>
                            <input
                              type="number"
                              placeholder="kg"
                              value={log.weight || ''}
                              onChange={(e) => logSet(exIndex, setIndex, e.target.value, log.reps)}
                              className="w-20 bg-gray-700 rounded px-2 py-1.5 text-center text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                            />
                            <span className="text-gray-500">×</span>
                            <input
                              type="number"
                              placeholder="reps"
                              value={log.reps || ''}
                              onChange={(e) => logSet(exIndex, setIndex, log.weight, e.target.value)}
                              className="w-20 bg-gray-700 rounded px-2 py-1.5 text-center text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                            />
                            <button
                              onClick={() => { setTimerValue(restTimer); setTimerRunning(true); }}
                              className="ml-auto bg-purple-600 hover:bg-purple-700 p-1.5 rounded-lg transition-colors"
                            >
                              <Timer className="w-4 h-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <button
              onClick={finishWorkout}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 py-4 rounded-xl font-bold text-lg transition-all shadow-lg"
            >
              🎉 Finish Workout
            </button>
          </div>
        )}

        {/* LOG TAB */}
        {activeTab === 'log' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Daily Log</h2>
              <span className="text-sm text-gray-400">{today.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}</span>
            </div>

            {/* Macro Targets */}
            <div className="bg-gray-800 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <Target className="w-4 h-4 text-purple-400" />
                  Today's Targets ({isRestDay ? 'Rest Day' : 'Training Day'})
                </h3>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center text-sm">
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <Zap className="w-4 h-4 mx-auto mb-1 text-yellow-400" />
                  <p className="font-bold">{macroTarget.calories}</p>
                  <p className="text-xs text-gray-400">kcal</p>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <Beef className="w-4 h-4 mx-auto mb-1 text-red-400" />
                  <p className="font-bold">{macroTarget.protein}g</p>
                  <p className="text-xs text-gray-400">protein</p>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <Apple className="w-4 h-4 mx-auto mb-1 text-green-400" />
                  <p className="font-bold">{macroTarget.carbs}g</p>
                  <p className="text-xs text-gray-400">carbs</p>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-2">
                  <Droplets className="w-4 h-4 mx-auto mb-1 text-blue-400" />
                  <p className="font-bold">{macroTarget.fat}g</p>
                  <p className="text-xs text-gray-400">fat</p>
                </div>
              </div>
            </div>

            {/* Input Form */}
            <div className="bg-gray-800 rounded-xl p-4 space-y-4">
              <h3 className="font-semibold">Log Your Day</h3>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="72.0"
                    value={todayLog.weight}
                    onChange={(e) => setTodayLog({ ...todayLog, weight: e.target.value })}
                    className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Sleep (hours)</label>
                  <input
                    type="number"
                    step="0.5"
                    placeholder="7.5"
                    value={todayLog.sleep}
                    onChange={(e) => setTodayLog({ ...todayLog, sleep: e.target.value })}
                    className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Calories</label>
                  <input
                    type="number"
                    placeholder="2350"
                    value={todayLog.calories}
                    onChange={(e) => setTodayLog({ ...todayLog, calories: e.target.value })}
                    className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Protein (g)</label>
                  <input
                    type="number"
                    placeholder="145"
                    value={todayLog.protein}
                    onChange={(e) => setTodayLog({ ...todayLog, protein: e.target.value })}
                    className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Carbs (g)</label>
                  <input
                    type="number"
                    placeholder="275"
                    value={todayLog.carbs}
                    onChange={(e) => setTodayLog({ ...todayLog, carbs: e.target.value })}
                    className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Fat (g)</label>
                  <input
                    type="number"
                    placeholder="65"
                    value={todayLog.fat}
                    onChange={(e) => setTodayLog({ ...todayLog, fat: e.target.value })}
                    className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-gray-400 mb-1 block">Water (L)</label>
                <input
                  type="number"
                  step="0.5"
                  placeholder="3.0"
                  value={todayLog.water}
                  onChange={(e) => setTodayLog({ ...todayLog, water: e.target.value })}
                  className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div>
                <label className="text-xs text-gray-400 mb-1 block">Notes</label>
                <textarea
                  placeholder="How do you feel? Energy levels, mood..."
                  value={todayLog.notes}
                  onChange={(e) => setTodayLog({ ...todayLog, notes: e.target.value })}
                  rows={2}
                  className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                />
              </div>

              <button
                onClick={saveDailyLog}
                className="w-full bg-purple-600 hover:bg-purple-700 py-3 rounded-xl font-semibold transition-colors"
              >
                Save Today's Log
              </button>
            </div>

            {/* Recent Logs */}
            {dailyLogs.length > 0 && (
              <div className="bg-gray-800 rounded-xl p-4">
                <h3 className="font-semibold mb-3">Recent Logs</h3>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {dailyLogs.slice(0, 7).map((log, i) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-gray-700/50 rounded-lg text-sm">
                      <span className="text-gray-400">
                        {new Date(log.date).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}
                      </span>
                      <div className="flex items-center gap-3">
                        {log.weight && <span>{log.weight}kg</span>}
                        {log.protein && <span className="text-red-400">{log.protein}g P</span>}
                        {log.calories && <span className="text-yellow-400">{log.calories}kcal</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* PROGRESS TAB */}
        {activeTab === 'progress' && (
          <div className="space-y-5">
            {/* Monthly Progress */}
            {monthlyProgress && (
              <div className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 rounded-xl p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-purple-400" /> 30-Day Progress
                </h3>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-3xl font-bold">{monthlyProgress.endWeight}kg</p>
                    <p className="text-sm text-gray-400">Current Weight</p>
                  </div>
                  <div className={`text-right ${parseFloat(monthlyProgress.change) < 0 ? 'text-green-400' : 'text-orange-400'}`}>
                    <p className="text-2xl font-bold">{parseFloat(monthlyProgress.change) > 0 ? '+' : ''}{monthlyProgress.change}kg</p>
                    <p className="text-sm opacity-70">This Month</p>
                  </div>
                </div>
                
                <div className="mt-4 h-24 flex items-end gap-1">
                  {monthlyProgress.data.slice(-14).map((m, i) => {
                    const min = Math.min(...monthlyProgress.data.map(d => d.weight));
                    const max = Math.max(...monthlyProgress.data.map(d => d.weight));
                    const range = max - min || 1;
                    const height = ((m.weight - min) / range) * 100;
                    return (
                      <div
                        key={i}
                        className="flex-1 bg-purple-500 rounded-t transition-all hover:bg-purple-400"
                        style={{ height: `${Math.max(height, 10)}%` }}
                        title={`${m.weight}kg`}
                      />
                    );
                  })}
                </div>
                <p className="text-xs text-gray-500 mt-1 text-center">Last 14 weigh-ins</p>
              </div>
            )}

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-gray-800 rounded-xl p-4 text-center">
                <Calendar className="w-6 h-6 mx-auto mb-2 text-purple-400" />
                <p className="text-2xl font-bold">{workoutHistory.length}</p>
                <p className="text-xs text-gray-400">Total Workouts</p>
              </div>
              <div className="bg-gray-800 rounded-xl p-4 text-center">
                <Flame className="w-6 h-6 mx-auto mb-2 text-orange-400" />
                <p className="text-2xl font-bold">{streak}</p>
                <p className="text-xs text-gray-400">Day Streak</p>
              </div>
              <div className="bg-gray-800 rounded-xl p-4 text-center">
                <Trophy className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
                <p className="text-2xl font-bold">{Object.keys(personalBests).length}</p>
                <p className="text-xs text-gray-400">Personal Bests</p>
              </div>
            </div>

            {/* Weekly Check-ins Summary */}
            {weeklyCheckins.length > 0 && (
              <div className="bg-gray-800 rounded-xl p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-400" /> Recent Check-ins
                </h3>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {weeklyCheckins.slice(0, 4).map((c, i) => (
                    <div key={i} className="p-2 bg-gray-700/50 rounded-lg text-sm">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium">Week {c.week}</span>
                        <span className="text-xs text-gray-400">
                          {new Date(c.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400">{c.answers.weight_change} • {c.answers.gym_performance}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Cheat Meals Log */}
            {cheatMeals.length > 0 && (
              <div className="bg-gray-800 rounded-xl p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Pizza className="w-5 h-5 text-pink-400" /> Cheat Meals
                </h3>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {cheatMeals.slice(0, 4).map((c, i) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-gray-700/50 rounded-lg text-sm">
                      <div className="flex items-center gap-2">
                        <span>{c.emoji}</span>
                        <span>{c.meal}</span>
                      </div>
                      <span className="text-xs text-gray-400">
                        {new Date(c.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Personal Bests */}
            {Object.keys(personalBests).length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-yellow-400" /> Personal Bests
                </h3>
                <div className="bg-gray-800 rounded-xl divide-y divide-gray-700 max-h-64 overflow-y-auto">
                  {Object.entries(personalBests).sort((a, b) => b[1] - a[1]).map(([exercise, weight]) => (
                    <div key={exercise} className="p-3 flex items-center justify-between">
                      <span className="font-medium text-sm">{exercise}</span>
                      <span className="text-purple-400 font-bold">{weight}kg</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {workoutHistory.length > 0 && (
              <button
                onClick={clearAllData}
                className="w-full bg-red-900/30 hover:bg-red-900/50 text-red-400 py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
              >
                <Trash2 className="w-4 h-4" /> Clear All Data
              </button>
            )}
          </div>
        )}

        {/* PHOTOS TAB */}
        {activeTab === 'photos' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Progress Photos</h2>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Upload className="w-4 h-4" /> Add Photo
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </div>

            <div className="bg-gray-800/50 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-400 mt-0.5" />
                <div className="text-sm text-gray-400">
                  <p className="font-medium text-gray-300 mb-1">Photo Tips</p>
                  <ul className="space-y-1">
                    <li>• Same lighting & angle each time</li>
                    <li>• Morning, after toilet, before food</li>
                    <li>• Take front, side & back views</li>
                    <li>• Weekly or bi-weekly is ideal</li>
                  </ul>
                </div>
              </div>
            </div>

            {progressPhotos.length === 0 ? (
              <div className="bg-gray-800 rounded-xl p-8 text-center">
                <Camera className="w-12 h-12 mx-auto mb-3 text-gray-600" />
                <p className="text-gray-400">No progress photos yet.</p>
                <p className="text-sm text-gray-500 mt-1">Start documenting your transformation!</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {progressPhotos.map((photo, i) => (
                  <div key={i} className="relative group">
                    <img
                      src={photo.data}
                      alt={`Progress ${i + 1}`}
                      className="w-full aspect-square object-cover rounded-xl"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2 rounded-b-xl">
                      <p className="text-xs text-white">
                        {new Date(photo.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        {photo.weight && ` • ${photo.weight}kg`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {progressPhotos.length >= 2 && (
              <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-xl p-4">
                <h3 className="font-semibold mb-2">Comparison</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-xs text-gray-400 mb-1 text-center">First</p>
                    <img
                      src={progressPhotos[progressPhotos.length - 1].data}
                      alt="First"
                      className="w-full aspect-square object-cover rounded-xl"
                    />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 mb-1 text-center">Latest</p>
                    <img
                      src={progressPhotos[0].data}
                      alt="Latest"
                      className="w-full aspect-square object-cover rounded-xl"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TIMER TAB */}
        {activeTab === 'timer' && (
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-2xl p-8 text-center">
              <p className={`text-7xl font-mono font-bold mb-6 ${timerValue <= 10 && timerRunning ? 'text-red-400 animate-pulse' : ''}`}>
                {formatTime(timerValue)}
              </p>
              <div className="flex justify-center gap-3">
                <button
                  onClick={() => setTimerRunning(!timerRunning)}
                  className={`p-4 rounded-full transition-colors ${
                    timerRunning ? 'bg-orange-600 hover:bg-orange-700' : 'bg-green-600 hover:bg-green-700'
                  }`}
                >
                  {timerRunning ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
                </button>
                <button
                  onClick={() => { setTimerRunning(false); setTimerValue(restTimer); }}
                  className="p-4 rounded-full bg-gray-700 hover:bg-gray-600 transition-colors"
                >
                  <RotateCcw className="w-8 h-8" />
                </button>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-gray-400 mb-3">Rest Duration</h3>
              <div className="grid grid-cols-4 gap-2">
                {REST_PRESETS.map(seconds => (
                  <button
                    key={seconds}
                    onClick={() => { setRestTimer(seconds); setTimerValue(seconds); }}
                    className={`py-3 rounded-xl font-semibold transition-colors ${
                      restTimer === seconds ? 'bg-purple-600' : 'bg-gray-800 hover:bg-gray-700'
                    }`}
                  >
                    {formatTime(seconds)}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-4">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Info className="w-4 h-4 text-purple-400" /> Your Plan's Rest Times
              </h4>
              <ul className="text-sm text-gray-400 space-y-1">
                <li>• <strong>Heavy compounds:</strong> 2-3 min (squats, deadlifts, bench)</li>
                <li>• <strong>Accessories:</strong> 1.5-2 min (rows, curls, extensions)</li>
                <li>• <strong>Pump work:</strong> 45-60s (lateral raises, face pulls)</li>
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Floating Timer */}
      {timerRunning && activeTab !== 'timer' && (
        <div
          onClick={() => setActiveTab('timer')}
          className={`fixed bottom-4 right-4 rounded-full px-4 py-2 flex items-center gap-2 shadow-lg cursor-pointer transition-colors ${
            timerValue <= 10 ? 'bg-red-600 animate-pulse' : 'bg-purple-600 hover:bg-purple-700'
          }`}
        >
          <Timer className="w-4 h-4" />
          <span className="font-mono font-bold">{formatTime(timerValue)}</span>
        </div>
      )}

      {/* Cheat Meal Modal */}
      {showCheatMealModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-2xl p-5 w-full max-w-md max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Pizza className="w-5 h-5 text-pink-400" /> Log Cheat Meal
              </h3>
              <button onClick={() => setShowCheatMealModal(false)} className="text-gray-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-2">
              {CHEAT_MEAL_OPTIONS.map((meal, i) => (
                <button
                  key={i}
                  onClick={() => logCheatMeal(meal)}
                  className="w-full bg-gray-700 hover:bg-gray-600 rounded-xl p-3 text-left transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{meal.emoji}</span>
                    <div>
                      <p className="font-semibold">{meal.name}</p>
                      <p className="text-xs text-gray-400">{meal.description}</p>
                      <p className="text-xs text-pink-400">{meal.calories} kcal</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Weekly Check-in Modal */}
      {showCheckinModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-2xl p-5 w-full max-w-md max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-400" /> Weekly Check-in
              </h3>
              <button onClick={() => setShowCheckinModal(false)} className="text-gray-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              {CHECKIN_QUESTIONS.map((q) => (
                <div key={q.id}>
                  <label className="text-sm font-medium mb-2 block">{q.question}</label>
                  {q.type === 'select' ? (
                    <div className="space-y-1">
                      {q.options.map((opt, i) => (
                        <button
                          key={i}
                          onClick={() => setCheckinAnswers({ ...checkinAnswers, [q.id]: opt })}
                          className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                            checkinAnswers[q.id] === opt
                              ? 'bg-purple-600 text-white'
                              : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <textarea
                      value={checkinAnswers[q.id] || ''}
                      onChange={(e) => setCheckinAnswers({ ...checkinAnswers, [q.id]: e.target.value })}
                      placeholder="Any observations..."
                      rows={2}
                      className="w-full bg-gray-700 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500 resize-none text-sm"
                    />
                  )}
                </div>
              ))}
              <button
                onClick={saveWeeklyCheckin}
                className="w-full bg-green-600 hover:bg-green-700 py-3 rounded-xl font-semibold transition-colors"
              >
                Save Check-in
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
