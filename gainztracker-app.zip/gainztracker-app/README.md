# 💪 Veke's GainzTracker

A complete 6-Day PPL muscle building & fat loss tracker built for your specific plan.

## Features

- ✅ Full 6-day PPL workout split from your PDF
- ✅ Daily logging (weight, macros, sleep, water)
- ✅ Monthly progress charts
- ✅ Personal bests tracking
- ✅ Rest timer with notifications
- ✅ Cheat meal tracker (Saturday)
- ✅ Weekly check-ins (Sunday)
- ✅ Progress photo diary
- ✅ Export to CSV
- ✅ PWA installable on mobile

---

## 🚀 Quick Start (Run Locally)

### Prerequisites

You need **Node.js** installed. Download from: https://nodejs.org (LTS version)

### Step 1: Open Terminal/Command Prompt

**Windows:** Press `Win + R`, type `cmd`, press Enter  
**Mac:** Press `Cmd + Space`, type `Terminal`, press Enter

### Step 2: Navigate to the app folder

```bash
cd path/to/gainztracker-app
```

### Step 3: Install dependencies

```bash
npm install
```

### Step 4: Start the development server

```bash
npm run dev
```

You'll see something like:
```
  VITE v5.0.0  ready in 500 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: http://192.168.1.xxx:3000/
```

### Step 5: Open on your mobile

1. Make sure your phone is on the **same WiFi** as your computer
2. Open the **Network** URL (e.g., `http://192.168.1.xxx:3000/`) in your phone's browser
3. The app will load!

---

## 📱 Install as App on Mobile

Once the app is running and you've opened it on your phone:

### iPhone (Safari)
1. Tap the **Share** button (square with arrow)
2. Scroll down and tap **"Add to Home Screen"**
3. Tap **"Add"**

### Android (Chrome)
1. Tap the **three dots** menu (⋮)
2. Tap **"Add to Home Screen"** or **"Install App"**
3. Tap **"Install"**

The app will now appear on your home screen like a native app!

---

## 🔔 Enable Notifications

1. Open the app
2. Tap the **bell icon** (🔔) in the header
3. Allow notifications when prompted
4. You'll get alerts when:
   - Rest timer finishes
   - It's workout time (if browser tab is open)

---

## 📂 Project Structure

```
gainztracker-app/
├── public/
│   ├── manifest.json    # PWA config
│   └── icon.svg         # App icon
├── src/
│   ├── App.jsx          # Main app component
│   ├── main.jsx         # Entry point
│   └── index.css        # Styles
├── index.html           # HTML template
├── package.json         # Dependencies
├── vite.config.js       # Vite config
├── tailwind.config.js   # Tailwind CSS config
└── README.md            # This file
```

---

## 🛠️ Troubleshooting

### "npm: command not found"
→ Install Node.js from https://nodejs.org

### "Cannot access on mobile"
→ Make sure phone and computer are on the same WiFi network
→ Check your firewall isn't blocking port 3000

### "Storage not working"
→ The app uses localStorage. Make sure you're not in private/incognito mode.

### "Notifications not working"
→ Check browser notification permissions in Settings
→ iOS Safari has limited notification support

---

## 📊 Export Your Data

1. Tap the **download icon** (⬇️) in the header
2. A CSV file will download with all your:
   - Workout history
   - Daily logs
   - Personal bests
   - Weekly check-ins
   - Cheat meals

Open in Excel or Google Sheets to analyse your progress!

---

## 🎯 Your Goals (from PDF)

- **Current:** 72 kg
- **Target:** 68-69 kg
- **Timeline:** 8-10 weeks
- **Rate:** 0.5-1 kg/week

### Training Day Macros
- Calories: 2,300-2,400 kcal
- Protein: 115-145g
- Carbs: 250-300g
- Fat: 60-70g

### Rest Day Macros
- Calories: 1,800-2,000 kcal
- Protein: 133g
- Carbs: 113g
- Fat: 37g

---

Made with 💪 for Veke | Edinburgh, UK
